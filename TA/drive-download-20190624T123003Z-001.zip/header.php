<!DOCTYPE html>
<html lang="en">
    <head>

        <title>Photography Portofolio</title>
   
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
       
       
    </head>
    <script src="js/bootstrap.js" type="text/javascript"></script>
<?php 
include('dbcon.php');
?>
